(function() {
	$('ul').append('<li>test</li>');
})();
