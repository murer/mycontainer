(function() {
	return "test2";
})();
