(function() {
	return "test1";
})();
